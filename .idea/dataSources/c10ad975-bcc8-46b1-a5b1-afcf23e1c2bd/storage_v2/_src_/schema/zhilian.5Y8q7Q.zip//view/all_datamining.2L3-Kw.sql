create view all_datamining as
  select
    `zhilian`.`all_zhiwei`.`职位`   AS `职位`,
    `zhilian`.`all_zhiwei`.`薪资`   AS `薪资`,
    `zhilian`.`all_zhiwei`.`工作地点` AS `工作地点`,
    `zhilian`.`all_zhiwei`.`学历要求` AS `学历要求`,
    `zhilian`.`all_zhiwei`.`岗位性质` AS `岗位性质`,
    `zhilian`.`all_zhiwei`.`发布时间` AS `发布时间`
  from `zhilian`.`all_zhiwei`
  where (`zhilian`.`all_zhiwei`.`职位` like '%数据挖掘%');

