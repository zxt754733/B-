create view zhiwei as
  select
    `zhilian`.`all_zhiwei`.`job_url` AS `job_url`,
    `zhilian`.`all_zhiwei`.`招聘部门`    AS `招聘部门`,
    `zhilian`.`all_zhiwei`.`职位`      AS `职位`,
    `zhilian`.`all_zhiwei`.`薪资`      AS `薪资`,
    `zhilian`.`all_zhiwei`.`工作地点`    AS `工作地点`,
    `zhilian`.`all_zhiwei`.`经验要求`    AS `经验要求`,
    `zhilian`.`all_zhiwei`.`学历要求`    AS `学历要求`,
    `zhilian`.`all_zhiwei`.`岗位性质`    AS `岗位性质`,
    `zhilian`.`all_zhiwei`.`职位诱惑`    AS `职位诱惑`,
    `zhilian`.`all_zhiwei`.`发布时间`    AS `发布时间`,
    `zhilian`.`all_zhiwei`.`职位描述`    AS `职位描述`,
    `zhilian`.`all_zhiwei`.`官网url`   AS `官网url`,
    `zhilian`.`all_zhiwei`.`公司地点`    AS `公司地点`,
    `zhilian`.`all_zhiwei`.`发布时间点`   AS `发布时间点`,
    `zhilian`.`all_zhiwei`.`写入时间`    AS `写入时间`
  from `zhilian`.`all_zhiwei`
  union select
          `zhilian`.`lagou_zhiwei`.`job_url` AS `job_url`,
          `zhilian`.`lagou_zhiwei`.`招聘部门`    AS `招聘部门`,
          `zhilian`.`lagou_zhiwei`.`职位`      AS `职位`,
          `zhilian`.`lagou_zhiwei`.`薪资`      AS `薪资`,
          `zhilian`.`lagou_zhiwei`.`工作地点`    AS `工作地点`,
          `zhilian`.`lagou_zhiwei`.`经验要求`    AS `经验要求`,
          `zhilian`.`lagou_zhiwei`.`学历要求`    AS `学历要求`,
          `zhilian`.`lagou_zhiwei`.`岗位性质`    AS `岗位性质`,
          `zhilian`.`lagou_zhiwei`.`职位诱惑`    AS `职位诱惑`,
          `zhilian`.`lagou_zhiwei`.`发布时间`    AS `发布时间`,
          `zhilian`.`lagou_zhiwei`.`职位描述`    AS `职位描述`,
          `zhilian`.`lagou_zhiwei`.`官网url`   AS `官网url`,
          `zhilian`.`lagou_zhiwei`.`公司地点`    AS `公司地点`,
          `zhilian`.`lagou_zhiwei`.`发布时间点`   AS `发布时间点`,
          `zhilian`.`lagou_zhiwei`.`写入时间`    AS `写入时间`
        from `zhilian`.`lagou_zhiwei`;

