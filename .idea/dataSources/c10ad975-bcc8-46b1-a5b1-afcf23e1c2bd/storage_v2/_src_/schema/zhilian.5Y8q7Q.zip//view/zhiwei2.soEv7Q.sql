create view zhiwei2 as
  select
    `zhilian`.`all_zhiwei`.`job_url` AS `job_url`,
    `zhilian`.`all_zhiwei`.`发布时间`    AS `fdate`
  from `zhilian`.`all_zhiwei`
  union select
          `zhilian`.`lagou_zhiwei`.`job_url` AS `job_url`,
          `zhilian`.`lagou_zhiwei`.`发布时间`    AS `fdate`
        from `zhilian`.`lagou_zhiwei`;

